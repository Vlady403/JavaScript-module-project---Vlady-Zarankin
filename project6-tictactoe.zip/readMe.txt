This application displays a Tic Tac Toe game.

Features include:

- Turn detection via a hovering effect.

- Win and draw check.
