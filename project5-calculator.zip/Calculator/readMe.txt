This Application displays a calculator using OOP in TypeScript.

The programs allows for all the standart functionality of a calculator, 

including:

- Decimal numbers

- Big numbers seperated by commas

- Two rows in the screen, one for the current number entered, the second for the first number and the math operation

- Continues, multi calculation computation 