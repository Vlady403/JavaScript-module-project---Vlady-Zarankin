To do list

This application allows users to add tasks to a list, by pressing the Enter key.

The tasks are added both to the screen and to the local storage.

There are buttons that are created with each task.

The "Completed" button - marks the task as completed.

The "Delete" button deletes the task from the screen as well as from the local storage.

The "Edit" button allows to make changes in the content of the task and save them in the same task through the "Save" button. The changes will be updated in the local storage as well.

When a task is marked as completed, The mark(v) symbol will restore it back to original.

The "Delete all tasks" button deletes all the tasks from the screen and from he local storage and empties it.

There are restrictions to adding the tasks, minimum 10 and maximum 25 characters are required for each task.





