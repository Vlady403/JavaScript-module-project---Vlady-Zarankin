Project 1 - Snake Game

The first screen that appears is a welcoming one.

There are two clickable elements: 

a. "Start the game"

b. "Instructions" - which explains how to play.

After clicking "Start the game" the game will be loaded, including the board of the game itself

as well as the stats: 

The timer, the score and the remaining lives.

The goal is to catch as many apples while avoiding three obstacles.

Although there are three lives initially, they relate to the snake hitting the obstacles only, each hit removes one life.

If the snake hits one of the borders or itself - the game will end regardless of how many lives remain.

A help in a form of a life icon will appear during the game to assist "surviving" if necessary.

*Though the game is responsive, it's not playable on mobile devices, approved by Elyashiv.


