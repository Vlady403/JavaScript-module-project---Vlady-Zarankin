Memory game

The first page:

The user decides how many pair of numbers, row and columns will there be,

As well as choose the name of both players.

Restrictions:

Max amount of pairs: 15

Max amount of columns is 10

Max amount of rows is 8

At least two characters are required for each player's name input.

Once the user enters fills the inputs correctly, the game uploads.

There is tracking of the amount of attempts for each player.

The circle around the name of the player marks whose turn is it.

The winner is obviously the one with less attempts.

