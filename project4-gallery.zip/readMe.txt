Gallery

This app uses OOP to create and handle an image gallery.

The user can change images either via the buttons or the left and right arrow keys.

The button at the top initiates and stops an automatic slideshow.

Clicking on the image will enlarge the image and open the full screen mode, removing the buttons.

